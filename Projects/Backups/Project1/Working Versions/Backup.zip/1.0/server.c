//Danny DeRuiter

#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main(int argc, char **argv)
{
        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        int port;
        int clientsocket;
        //get the port
        printf("Enter a port: ");
        scanf("%d", &port);
        //server is specifying its own address
        struct sockaddr_in serveraddr, clientaddr;
        serveraddr.sin_family = AF_INET;
        serveraddr.sin_port = htons(port);
        serveraddr.sin_addr.s_addr = INADDR_ANY; //a catchall saying use any IP addr this computer has

        //Bind: Tie addr to socket saying when something is to be done with socket, use this addr
        bind(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr));

        //listens to specified socket
        //10 is number of turns until we stop listening
        listen(sockfd, 10);

        int len = sizeof(clientaddr);

        //Accept will fill in client addr struct
        //Accept is a blocking call
		clientsocket = accept(sockfd, (struct sockaddr*)&clientaddr, &len);
		if(clientsocket != NULL)
		{
			printf("Connection Established...\n");
		}
        while(1)
        {
			//message to be returned to the client
			char * returnmsg = "";
			char filename[20];
			memset(filename, 0, 20);
            recv(clientsocket, filename, sizeof(filename), 0);
			FILE *fp = fopen(filename, "rb");
			printf("Locating file");
			if(fp == NULL)
			{
				returnmsg = "Failed to locate file\n";
				send(clientsocket, returnmsg, strlen(returnmsg), 0);
		
			}
			else
			{
				printf("%s opened...\n", filename);
				while(1)
				{
					//read file in chunks
					unsigned char buff[256] = {0};
					int i = 0;
					while(fscanf(fp, "%c", &buff[i]) != EOF)
					{
						i++;
					}
					//int read = fread(buff,i 1, 256, fp);
					//printf("Bytes read %d \n", read);
				
					//send data chunk
					//if(read > 0)
					//{
					//	printf("Sending...\n");
						//write(clientsocket, buff, read);
						write(clientsocket, buff, sizeof(buff));
					//}
				
					//if(read < 256)
					//{
						if(feof(fp))
						{
							printf("End of File\n");
							break;
						}
						if(ferror(fp))
						{
							printf("Error reading\n");
							break;
						}
				
					//	break;
					//}
				}
				break;
			}
        }
        close(clientsocket);
        return 0;
}
